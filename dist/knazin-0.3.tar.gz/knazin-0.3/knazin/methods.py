def siemanko():
    return 'Co tam u Ciebie slychac'