def test():
    return 'This is first package of knazin'